//图片轮播
$(function(){
	var list=document.getElementById("bannerImg");
	var Lis=list.getElementsByTagName("li");
	var imgBtn = document.getElementById("imgBtn");
	var btns = imgBtn.getElementsByTagName("a");
	var next = document.getElementById('next');
	var banner = document.getElementById('banner');
	var index = 0;
	var num = 2;
	var animated = false;
	var interval = 3000;
	var timer="";
	function animate(offset){
		var newLeft= parseInt(list.offsetLeft) + offset;
		//alert(newLeft);
		var time=300;
		var interval=10;
		var speed = offset/(time/interval);

        animated = true;
		function go(){
			animated = true;
			if((parseInt(list.offsetLeft) > newLeft && speed < 0) || 
				speed > 0 && ( parseInt(list.offsetLeft)< newLeft)){
				list.style.left = parseInt(list.offsetLeft) + speed + 'px';
				setTimeout(go,interval);
			}else{
				animated=false;
				list.style.left = newLeft + 'px';
				if(parseInt(list.offsetLeft) < -810*num){
					list.style.left = -810 + 'px';
				}
			}
		}		
		go();
	}

	for (var i = 0; i < Lis.length; i++) {
		Lis[i].onclick=function(){
			!function(){
				if(!animated){
					index++;
					animate(-810); 
					showButton();
				}
			}();
		}
	}
	next.onclick = function(event) {
		!function(){
				if(!animated){
					index++;
					animate(-810); 
					showButton();
				}
			}();
	};

	function showButton(){
		if(index == 5){
			index = 0;
		}
	    for(var i = 0;i<5;i++){
	    	if(btns[i].className == 'active'){
	    		btns[i].className = '';
	    		break;
	    	}
	    }	
        btns[index].className = 'active';
        }

    for (var i = 0; i < btns.length; i++) {
    	!function(i){
    		btns[i].onclick = function(){
    		var offset = (i-index ) * -810;
    		animate(offset);
    		index = i;
    		showButton();
    	  }
    	}(i);
    }
    function play(){
    	timer = setInterval(function(){
    		next.onclick();
    	},3000)
    }
    function stop(){
    	clearInterval(timer);
    }
 //   play();
    list.onmouseover = stop;
 //   list.onmouseout = play;
})