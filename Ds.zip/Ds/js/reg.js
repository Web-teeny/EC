angular.module('myApp', [])
     .controller('SignUpController',function($scope){
     	$scope.userdata = {};
     	$scope.submitForm = function(){
     		console.log($scope.userdata);
     	}
     })
     .directive('compare',function(){
     	var o={};
     	o.strict = "AE";
     	o.scope = {
     		orgText:'=compare'
     	}
     	o.require = 'ngModel';
     	o.link = function(sco,ele,att,con){
     		con.$validators.compare = function(v){
     			return v == sco.orgText;
     		}
     		sco.$watch('orgText',function(){
     			con.$validate();
     		})
     	}
     	return o;
     })
$(function(){
	var username =  $("#username");
	var password =  $("#password");
	var password_con =  $("#password_con");
	var btn = $("#sub_btn");
	var p=$("#usernameBox p:last");
	btn.on('click',function(){
		alert(username.val());
	})
	username.on('blur',function(){
		$.ajax({
			url: 'http://127.0.0.1:8080/testAjax/service.php',
			type: 'GET',
			//dataType:'jsonp',
			jsonp: "callback",
			data: {username: username.val()},
			success:function(data){
				p.text("");
				if(!data.success){
					p.text('用户已存在！');
				}
				    
			}
		})			
	})
	username.on('focus',function(){
		//username.val("");
		p.text("");
	})
	
})